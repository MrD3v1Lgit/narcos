<?php
$chat_id = "1205577551"
//// telegram bot user is @NAVY_SALVABOT
//// make with love for ur mom
//// @SALVAadmin fuck ur mom
?>
