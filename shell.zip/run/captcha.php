<?php
session_start();

$capis_code = '';
$capisimg_height = 60;
$capisimg_width = 140;
$totechrimg = 6;

$possltrs = 'bcdfghjkmnpqrstvwxyz23456789';
$capis_font = __DIR__ . '/moe.ttf';

$random_capis_dots = 50;
$random_capis_lines = 25;
$capis_text_color = "0x142864";
$capis_noise_color = "0x142864";

$bkimg = imagecreatefrompng(__DIR__ . '/img/cip.png');

$count = 0;
while ($count < $totechrimg) {
    $capis_code .= substr(
        $possltrs,
        mt_rand(0, strlen($possltrs)-1),
        1);
    $count++;
}

$capis_font_size = $capisimg_height * 0.95;
$capisimg = @imagecreate(
    $capisimg_width,
    $capisimg_height
);

$background_color = imagecolorallocate(
    $capisimg,
    236,
    64,
    92
);

$array_text_color = hextorgb($capis_text_color);
$capis_text_color = imagecolorallocate(
    $bkimg,
    $array_text_color['red'],
    $array_text_color['green'],
    $array_text_color['blue']
);

$array_noise_color = hextorgb($capis_noise_color);
$image_noise_color = imagecolorallocate(
    $capisimg,
    $array_noise_color['red'],
    $array_noise_color['green'],
    $array_noise_color['blue']
);

for( $count=0; $count<$random_capis_dots; $count++ ) {
    imagefilledellipse(
        $capisimg,
        mt_rand(0,$capisimg_width),
        mt_rand(0,$capisimg_height),
        2,
        3,
        $image_noise_color
    );
}

for( $count=0; $count<$random_capis_lines; $count++ ) {
    imageline(
        $capisimg,
        mt_rand(0,$capisimg_width),
        mt_rand(0,$capisimg_height),
        mt_rand(0,$capisimg_width),
        mt_rand(0,$capisimg_height),
        $image_noise_color
    );
}

$text_box = imagettfbbox(
    $capis_font_size,
    0,
    $capis_font,
    $capis_code
);
$x = ($capisimg_width - $text_box[5])/2.2;
$y = ($capisimg_height - $text_box[5])/2;
imagettftext(
    $bkimg,
    $capis_font_size,
    0,
    $x,
    $y,
    $capis_text_color,
    $capis_font,
    $capis_code
);

header('Content-Type: image/jpeg');
imagejpeg($bkimg);
imagedestroy($bkimg);
$_SESSION['capis'] = $capis_code;

function hextorgb ($hexstring){
    $integar = hexdec($hexstring);
    return array("red" => 0xFF & ($integar >> 0x10),
        "green" => 0xFF & ($integar >> 0x8),
        "blue" => 0xFF & $integar);
}
?>