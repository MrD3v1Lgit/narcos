<?php
####Added By 0xMrC0ns0rt####
//Money will make you a human, Money is good, Be like the money.
###
$telegram ='on';//Send messages via telegram? (on or off)
$token = 'bot'.'TYPE HERE';
$chatid = '';
$sendnum = '2';//This is how many the message will be sent to you (any number allowed!)
?>